<div id="com-head">
    <div class="com-title">部落格</div>
    <div class="com-content">
        <div class="blogL">
            <div class="blog-date">Dec 31, 2013</div>
            <div class="blog-title"><a href="blog-more.php">小朋友腳掌塌塌，要緊嗎？</a></div>
            <div class="blog-pic"><img src="./images/blog-pic-1.jpg" width="598" height="178" /></div>
            <div class="blog-text">走四方客製鞋墊的類別，主要是以半客製或是全訂製的醫療極鞋墊為主力，一切以實用及效果為主要訴求，也因為這樣，無法兼顧所謂的外觀或多彩複合材料等噱頭（因為材料使用愈多，代表著損壞速度越快）。而鞋墊的優劣，有90%取決於製作及評估者的專業度，這也是主要的成本來源，請不要用一般市面上其它的鞋墊價格來議價，相信且尊重我們的專業，走四方會給您最好的服務。<br /><a href="blog-more.php">(繼續閱讀)</a></div>
        </div>
        <div class="blogR">
            <div class="blogR-title">最新文章</div>
            <div class="dotline-1"></div>
            <div class="latest-blog">
               	<div class="latest-blog-pic"><img src="./images/blog-pic-1.png" width="66" height="66" /></div>
                <div class="latest-blog-text">
                    Dec 31, 2013<br />
                    <span><a href="#">小朋友腳掌塌塌要緊嗎？</a></span>
                </div>
            </div>
            <div class="dotline-1"></div>
            <div class="latest-blog">
               	<div class="latest-blog-pic"><img src="./images/blog-pic-1.png" width="66" height="66" /></div>
                <div class="latest-blog-text">
                    Dec 31, 2013<br />
                    <span><a href="#">小朋友腳掌塌塌要緊嗎？</a></span>
                </div>
            </div>
            <div class="dotline-1"></div>
            <div class="latest-blog">
               	<div class="latest-blog-pic"><img src="./images/blog-pic-1.png" width="66" height="66" /></div>
                <div class="latest-blog-text">
                    Dec 31, 2013<br />
                    <span><a href="#">小朋友腳掌塌塌要緊嗎？</a></span>
                </div>
            </div>
            <div class="dotline-1"></div>
            <div class="latest-blog">
               	<div class="latest-blog-pic"><img src="./images/blog-pic-1.png" width="66" height="66" /></div>
                <div class="latest-blog-text">
                    Dec 31, 2013<br />
                    <span><a href="#">小朋友腳掌塌塌要緊嗎？</a></span>
                </div>
            </div>
            <div class="dotline-1"></div>
            <div class="blogR-title-2">文章分類</div>
            <div class="dotline-1"></div>
            <div class="article-category"><a href="#">案例分享</a></div>
            <div class="dotline-1"></div>
            <div class="article-category"><a href="#">製作流程</a></div>
            <div class="dotline-1"></div>
            <div class="article-category"><a href="#">關於鞋墊</a></div>
            <div class="dotline-1"></div>
            <div class="space"></div>
        </div>

    </div>
</div>
<div class="space"></div>