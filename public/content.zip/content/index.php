<div id="main">
    <div id="big">
        <img src="./images/11.gif" />
        <h1>四大保證</h1>
        <ul>
            <li>堅持使用專業壓力板及電腦評估獨創</li>
            <li>堅持直正個別客製</li>
            <li>一年完全保固</li>
            <li>專業後製-完全符合您的腳及鞋子</li>
        </ul>
    </div>
    <div id="small">
        <ul>
            <li>
                <img src="./images/12.gif" /><span>舒適小牛皮舒適小牛皮</span>
            </li>
            <li>
                <img src="./images/13.gif" /><span>巴斯光年藍光材質</span>
            </li>
            <li>
                <img src="./images/14.gif" /><span>純柚木製</span>
            </li>
        </ul>
    </div>
</div>
<div id="connection">
    <div class="connection-pic1">
        <a href="blog.php">常見問題</a>
    </div>
    <div class="connection-pic2">
        <a href="mailto:savy203@gmail.com">預約檢測</a>
    </div>
    <div class="connection-pic3">
        <a href="news.php">最新消息</a>
    </div>
</div>