<div id="com-head">
    <div class="com-title">最新消息</div>
    <div class="com-content">
        <div class="newtable">
            <table id="newsTable" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <th width="6">
                        <img src="./images/news-tableL.gif" width="6" height="36" />
                    </th>
                    <th class="news-title-bg" width="80"><span class="font-blue-16">編號</span></th>
                    <th width="40"><img src="./images/news-table-div.gif" width="41" height="36" /></th>
                    <th class="news-title-bg" width="160"><span class="font-blue-16">刊登日期</span></th>
                    <th width="40"><img src="./images/news-table-div.gif" width="41" height="36" /></th>
                    <th class="news-title-bg"><span class="font-blue-16">訊息標題</span></th>
                    <th width="6">
                        <img src="./images/news-tableR.gif" width="6" height="36" />
                    </th>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">1</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">2</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">3</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">4</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">5</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">6</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="1"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">7</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">8</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">9</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-line" height="9"></td>
                </tr>
                <tr height="35">
                    <td>&nbsp;</td>
                    <td class="font-gray-14" align="center">10</td>
                    <td>&nbsp;</td>
                    <td class="font-blue-13" align="center">2014-01-01</td>
                    <td>&nbsp;</td>
                    <td class="font-gray-14"><a href="news-more.php">足部輔具AFO SMO UCBL 上架啦</a></td>
                </tr>
                <tr>
                    <td colspan="6" class="news-endline" height="10"></td>
                </tr>
            </table>
        </div>
        <div id="news-number">
            <div id="news-left" class="font-gray-12">第 <strong>
                <span class="font-black-12">1</span></strong> 頁，共
                <strong><span class="font-black-12">12</span></strong> 筆
            </div>
            <div id="news-left" class="num">
                <a href="/News/?&amp;p=1"><img src="./images/com-page-3.gif"  alt="第一頁"  border="0" align="absmiddle"   /></a>
                <img src="./images/com-page-1.gif" alt="上一頁" border="0" align="absmiddle"   />
                <span class="cur">1</span>|  <a href="/News/?&amp;p=2" >2</a>
                <a href="/News/?&amp;p=2" ><img src="./images/com-page-2.gif" alt="下一頁"  border="0" align="absmiddle" /></a>
                <a href="/News/?&amp;p=2" ><img src="./images/com-page-4.gif" alt="最後一頁" border="0" align="absmiddle" /></a>
            </div>
            <form name="frmPage" action="" method="get">
                <div id="news-right" class="font-gray-12">直接到第
                    <input name="p" type="text" maxlength="2"  value="1" id="p"  style="vertical-align: middle"  size="4" />
                    &nbsp;頁
                    <img  src="./images/com-page-5.gif" alt="前往指定頁面" style="border-width:0px;vertical-align: middle;" />
                </div>
            </form>
        </div>
    </div>
</div>