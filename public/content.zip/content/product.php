<div id="com-head">
    <div class="com-title">產品介紹</div>
    <div class="com-content">
        <div class="pro-list">
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product-2">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
        </div>
        <div class="pro-list">
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
            <div class="product-2">
                <div class="pro-pic">
                    <a href="#"><img src="./images/product-pic-3.png" width="165" height="162" border="0" /></a>
                </div>
                <div class="pro-title">
                    <a href="#">狠厲害鞋墊</a>
                </div>
            </div>
        </div>
    </div>
</div>