<div id="com-head">
    <div class="com-title">服務流程</div>
    <div class="com-content">
        <div class="service-text">
            <img src="./images/service-pic-2.png" width="450" height="791" /> <br /><br />
            <div class="service-pic">
                <img src="./images/service-pic-3.png" width="150" height="147" />
                <img src="./images/service-pic-4.png" width="150" height="147" />
                <img src="./images/service-pic-5.png" width="150" height="147" />
                <img src="./images/service-pic-6.png" width="150" height="147" />
                <img src="./images/service-pic-7.png" width="150" height="147" />
            </div>
        </div>
    </div>
</div>