<div id="footer">
    版權所有 &copy; 2014 走四方鞋墊中心&nbsp;&nbsp;<img src="./images/com-icon-5.gif" width="11" height="11" /> 營業時間：週二 - 週日14:00 - 20:00
    &nbsp;&nbsp;<img src="./images/com-icon-7.gif" width="11" height="11" /> 台中市北區忠明路139號&nbsp;&nbsp;
    <img src="./images/com-icon-6.gif" width="11" height="11" />&nbsp; 04-2320 9488
</div>