<div id="header">
    <div class="com-logo">
        <a href="index.php"><img src="./images/com-logo.png" width="187" height="100" /></a>
    </div>
    <div id="com-menu">
        <div class="menu-1"><a href="about.php">關於我們</a></div>
        <div class="menu-2"><a href="product.php">產品介紹</a></div>
        <div class="menu-2"><a href="maintain.php">維修中心</a></div>
        <div class="menu-2"><a href="service.php">服務流程</a></div>
        <div class="menu-2"><a href="news.php">最新消息</a></div>
        <div class="menu-2"><a href="blog.php">部落格</a></div>
    </div>
</div>