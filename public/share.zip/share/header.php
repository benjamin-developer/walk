<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>走四方鞋墊中心-首頁</title>
<link href="./cssStyle/gosifang.css" rel="stylesheet" type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>