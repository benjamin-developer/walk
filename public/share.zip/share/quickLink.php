<div id="content">
    <div class="contentInner">
        <div class="home-content-1">
            <div>
                <div class="home-title font-blue-24">關於我們</div>
                <div class="home-more"><a href="about.php"><img src="./images/more.gif" width="49" height="9" /></a></div>
            </div>
            <div class="dotline"></div>
            <div class="font-blue-14-1">
                限制字數160字走四方鞋墊並不只是賣產品，而是賣我們的專業及服務。我們用醫院等級的專業(專業物理治療師)，放在最為便民的門市，讓您離專業客製鞋墊不再遙遠，而這樣的模式讓我們更有時間讓您了解自己便民的門市，讓您離專業客製鞋墊不再遙遠，而這樣的模式讓我們更有時間讓您了解自己的狀況走四方鞋墊並不只是賣產品，走四方鞋墊並不只是賣產品...</div>
        </div>
        <div class="home-content-1">
            <div>
                <div class="home-title font-blue-24">部落格</div>
                <div class="home-more"><a href="blog.php"></a></div>
            </div>
            <div class="dotline"></div>
            <div class="font-blue-14">
                <span class="font-gray-10">2013-7-30</span><br />
                <span class="home-blog"><a href="blog-more.php">小朋友腳掌塌塌，要緊嗎？</a></span><br />
                其實幼童在學齡前1-6歲是腳掌發展的重要時期，3歲前扁平足是十常常見的，常常一站...
            </div>
            <div class="dotline-1"></div>
            <div class="font-blue-14">
                <span class="font-gray-10">2013-7-30</span><br />
                <span class="home-blog"><a href="blog-more.php">小朋友腳掌塌塌，要緊嗎？</a></span><br />
                其實幼童在學齡前1-6歲是腳掌發展的重要時期，3歲前扁平足是十常常見的，常常一站...
            </div>
        </div>
        <div class="home-content-2">
            <div>
                <div class="home-title font-blue-24">聯絡資訊</div>
            </div>
            <div class="dotline"></div>
            <div class="font-blue-14-1">
                營業時間：<br />
                台中  週二至週日 14:00~20:00 需預約<br />
                台北  週日至週一 10:00~22:00 需預約<br />
                預約專線：04-23209488<br />
                台中門市：北區忠明路139號<br />
                台北門市：中正區東門站1號出口
            </div>
            <div class="dotline-1"></div>
            <div class="share-4"><a href="mailto:savy203@gmail.com"></a></div>
            <div class="share-1"><a href="#"></a></div>
            <div class="share-2"><a href="#"></a></div>
            <div class="share-3"><a href="#"></a></div>
        </div>
    </div>
</div>